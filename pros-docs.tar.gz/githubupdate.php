<?php 
//This file will be used to update the website automatically from github. 
//This is set with server configs to only accessible from select IP ranges. 
`git pull`;
?>
